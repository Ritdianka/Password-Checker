from flask import Flask, render_template, request, jsonify
import hashlib
import ipaddress
import math
import os
import re
import socket

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)

MAX_PORT_RANGE = 300  # cap per scan so a request can't hang or hammer the local network

with open(os.path.join(BASE_DIR, 'database', 'common_passwords.txt'), encoding='utf-8') as f:
    COMMON = set(f.read().split())


@app.get('/')
def home():
    return render_template('index.html')


@app.post('/api/analyze')
def api():
    data = request.get_json(silent=True) or {}
    p = data.get('password', '')

    cs = 0
    for pat, n in [(r'[a-z]', 26), (r'[A-Z]', 26), (r'\d', 10), (r'[^A-Za-z0-9]', 33)]:
        if re.search(pat, p):
            cs += n

    ent = round(len(p) * math.log2(cs), 2) if cs else 0
    score = min(100, int(ent))

    if score < 26:
        lvl = 'Weak'
    elif score < 51:
        lvl = 'Medium'
    elif score < 76:
        lvl = 'Strong'
    else:
        lvl = 'Very Strong'

    checks = {
        'length': len(p) >= 12,
        'uppercase': bool(re.search(r'[A-Z]', p)),
        'lowercase': bool(re.search(r'[a-z]', p)),
        'number': bool(re.search(r'\d', p)),
        'symbol': bool(re.search(r'[^A-Za-z0-9]', p)),
    }
    dictionary_risk = p.lower() in COMMON

    recommendations = []
    if not checks['length']:
        recommendations.append('Use at least 12 characters (16+ is ideal)')
    if not checks['uppercase']:
        recommendations.append('Add an uppercase letter')
    if not checks['lowercase']:
        recommendations.append('Add a lowercase letter')
    if not checks['number']:
        recommendations.append('Add a number')
    if not checks['symbol']:
        recommendations.append('Add a special character')
    if dictionary_risk:
        recommendations.append('This is a very common password — avoid it entirely')
    if not recommendations:
        recommendations.append('Looks solid — meets all baseline criteria')

    return jsonify(
        score=score,
        strength=lvl,
        entropy=ent,
        length=len(p),
        dictionary_risk=dictionary_risk,
        checks=checks,
        recommendations=recommendations,
    )


@app.post('/api/portscan')
def portscan():
    data = request.get_json(silent=True) or {}
    host = (data.get('host') or '127.0.0.1').strip()

    try:
        start_port = int(data.get('start_port', 1))
        end_port = int(data.get('end_port', 100))
    except (TypeError, ValueError):
        return jsonify(error='Port harus berupa angka'), 400

    try:
        resolved_ip = socket.gethostbyname(host)
        ip_obj = ipaddress.ip_address(resolved_ip)
    except (socket.gaierror, ValueError):
        return jsonify(error='Host tidak dikenali'), 400

    # Only allow scanning localhost / private network ranges — never public hosts.
    if not (ip_obj.is_loopback or ip_obj.is_private):
        return jsonify(
            error='Hanya bisa scan localhost atau IP jaringan privat '
                  '(127.0.0.1, 192.168.x.x, 10.x.x.x, 172.16–31.x.x)'
        ), 400

    start_port = max(1, min(start_port, 65535))
    end_port = max(1, min(end_port, 65535))
    if end_port < start_port:
        start_port, end_port = end_port, start_port
    if end_port - start_port > MAX_PORT_RANGE:
        end_port = start_port + MAX_PORT_RANGE

    open_ports = []
    for port in range(start_port, end_port + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.3)
        try:
            if sock.connect_ex((resolved_ip, port)) == 0:
                try:
                    service = socket.getservbyport(port)
                except OSError:
                    service = 'unknown'
                open_ports.append({'port': port, 'service': service})
        finally:
            sock.close()

    return jsonify(
        host=resolved_ip,
        scanned_range=f'{start_port}-{end_port}',
        open_ports=open_ports,
        count=len(open_ports),
    )


@app.post('/api/integrity')
def integrity():
    if 'file' not in request.files or request.files['file'].filename == '':
        return jsonify(error='Tidak ada file yang diunggah'), 400

    f = request.files['file']
    hasher = hashlib.sha256()
    size = 0
    for chunk in iter(lambda: f.read(8192), b''):
        hasher.update(chunk)
        size += len(chunk)
    digest = hasher.hexdigest()

    compare_to = (request.form.get('compare_to') or '').strip().lower()
    match = (compare_to == digest) if compare_to else None

    return jsonify(filename=f.filename, sha256=digest, size=size, match=match)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
