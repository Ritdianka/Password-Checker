/* ---------------------------------------------------------
   Matrix rain background
   --------------------------------------------------------- */
(function matrixRain(){
  const canvas = document.getElementById('grid');
  const ctx = canvas.getContext('2d');
  const chars = 'アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789ABCDEF';
  const fontSize = 15;
  let w, h, cols, drops;

  function resize(){
    w = canvas.width = innerWidth;
    h = canvas.height = innerHeight;
    cols = Math.floor(w / fontSize);
    drops = new Array(cols).fill(0).map(() => Math.random() * -100);
  }

  function draw(){
    ctx.fillStyle = 'rgba(0,0,0,0.08)';
    ctx.fillRect(0, 0, w, h);
    ctx.font = fontSize + 'px monospace';

    for (let i = 0; i < cols; i++){
      const char = chars[Math.floor(Math.random() * chars.length)];
      const x = i * fontSize;
      const y = drops[i] * fontSize;

      // Leading character brighter, trail fades — classic matrix look
      ctx.fillStyle = 'rgba(180,255,180,0.85)';
      ctx.fillText(char, x, y);

      if (y > h && Math.random() > 0.975){
        drops[i] = 0;
      }
      drops[i]++;
    }
  }

  resize();
  onresize = resize;
  setInterval(draw, 45);
})();

/* ---------------------------------------------------------
   Spectrum meter (signature element)
   --------------------------------------------------------- */
const SPECTRUM_BARS = 28;
const spectrum = document.getElementById('spectrum');
for (let i = 0; i < SPECTRUM_BARS; i++){
  const bar = document.createElement('div');
  bar.className = 'bar';
  spectrum.appendChild(bar);
}
const bars = [...spectrum.children];

function renderSpectrum(score){
  // Deterministic-ish jitter so the meter reads as a live signal, not a plain bar
  const activeCount = Math.round((score / 100) * SPECTRUM_BARS);
  bars.forEach((bar, i) => {
    if (i >= activeCount){
      bar.style.height = '4px';
      bar.style.background = 'var(--panel-border)';
      bar.style.boxShadow = 'none';
      return;
    }
    const jitter = 0.55 + 0.45 * Math.abs(Math.sin(i * 12.9898 + score * 0.37));
    const heightPct = Math.min(100, (score / 100) * 100 * jitter + 10);
    const color = colorForScore(score);
    bar.style.height = Math.max(4, heightPct * 0.56) + 'px';
    bar.style.background = color;
    bar.style.boxShadow = `0 0 6px ${color}`;
  });
}

function colorForScore(score){
  if (score < 26) return 'var(--danger)';
  if (score < 51) return 'var(--warn)';
  if (score < 76) return 'var(--accent)';
  return 'var(--good)';
}

function tierClass(score){
  if (score < 26) return 'weak';
  if (score < 51) return 'medium';
  if (score < 76) return 'strong';
  return 'very-strong';
}

/* ---------------------------------------------------------
   UI wiring
   --------------------------------------------------------- */
const pw = document.getElementById('pw');
const toggleBtn = document.getElementById('toggleBtn');
const eyeIcon = document.getElementById('eyeIcon');
const statusPill = document.getElementById('statusPill');
const brandDot = document.getElementById('brandDot');

const strengthLabel = document.getElementById('strengthLabel');
const scoreValue = document.getElementById('scoreValue');
const entropyValue = document.getElementById('entropyValue');
const lengthValue = document.getElementById('lengthValue');
const dictValue = document.getElementById('dictValue');
const recList = document.getElementById('recList');
const checklist = document.getElementById('checklist');

toggleBtn.addEventListener('click', () => {
  const showing = pw.type === 'text';
  pw.type = showing ? 'password' : 'text';
  toggleBtn.setAttribute('aria-pressed', String(!showing));
  eyeIcon.innerHTML = showing
    ? '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/>'
    : '<path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a21.8 21.8 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 7 11 7a21.8 21.8 0 0 1-2.16 3.19M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
});

const CHECK_PATTERNS = {
  length: p => p.length >= 12,
  uppercase: p => /[A-Z]/.test(p),
  lowercase: p => /[a-z]/.test(p),
  number: p => /\d/.test(p),
  symbol: p => /[^A-Za-z0-9]/.test(p)
};

function updateChecklist(p){
  [...checklist.children].forEach(li => {
    const key = li.dataset.key;
    li.classList.toggle('met', CHECK_PATTERNS[key](p));
  });
}

function resetReadout(){
  strengthLabel.textContent = '—';
  strengthLabel.className = 'strength-value';
  scoreValue.innerHTML = '0<span class="stat-unit">/100</span>';
  entropyValue.innerHTML = '0<span class="stat-unit">bits</span>';
  lengthValue.innerHTML = '0<span class="stat-unit">chars</span>';
  dictValue.textContent = '—';
  dictValue.className = 'stat-value';
  recList.innerHTML = '<li class="rec-placeholder">Start typing to see feedback</li>';
  renderSpectrum(0);
  statusPill.textContent = 'STANDBY';
  brandDot.className = 'brand-dot';
}

let debounceTimer = null;

async function analyze(){
  const p = pw.value;

  if (!p){
    resetReadout();
    return;
  }

  statusPill.textContent = 'ANALYZING…';

  try{
    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: p })
    });
    const d = await res.json();

    const tier = tierClass(d.score);

    strengthLabel.textContent = d.strength;
    strengthLabel.className = 'strength-value ' + tier;

    scoreValue.innerHTML = `${d.score}<span class="stat-unit">/100</span>`;
    entropyValue.innerHTML = `${d.entropy}<span class="stat-unit">bits</span>`;
    lengthValue.innerHTML = `${d.length}<span class="stat-unit">chars</span>`;

    dictValue.textContent = d.dictionary_risk ? 'FOUND' : 'CLEAR';
    dictValue.className = 'stat-value ' + (d.dictionary_risk ? 'flag-bad' : 'flag-good');

    recList.innerHTML = '';
    d.recommendations.forEach(r => {
      const li = document.createElement('li');
      li.textContent = r;
      recList.appendChild(li);
    });

    renderSpectrum(d.score);
    statusPill.textContent = 'READY';
    brandDot.className = 'brand-dot ' + tier;
  } catch (err){
    statusPill.textContent = 'ERROR';
  }
}

pw.addEventListener('input', () => {
  updateChecklist(pw.value);
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(analyze, 200);
});

resetReadout();

/* ---------------------------------------------------------
   Tab switching
   --------------------------------------------------------- */
const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.tab-view');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');

    const target = tab.dataset.tab;
    panels.forEach(p => { p.hidden = p.dataset.tabPanel !== target; });
  });
});

/* ---------------------------------------------------------
   Port scanner
   --------------------------------------------------------- */
const scanHost = document.getElementById('scanHost');
const scanStart = document.getElementById('scanStart');
const scanEnd = document.getElementById('scanEnd');
const scanBtn = document.getElementById('scanBtn');
const scanCount = document.getElementById('scanCount');
const scanError = document.getElementById('scanError');
const portList = document.getElementById('portList');

scanBtn.addEventListener('click', async () => {
  scanError.hidden = true;
  scanBtn.disabled = true;
  scanBtn.textContent = 'Scanning…';
  portList.innerHTML = '<li class="rec-placeholder">Scanning…</li>';
  scanCount.textContent = '—';

  try {
    const res = await fetch('/api/portscan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        host: scanHost.value.trim() || '127.0.0.1',
        start_port: Number(scanStart.value) || 1,
        end_port: Number(scanEnd.value) || 100
      })
    });
    const d = await res.json();

    if (!res.ok) {
      scanError.textContent = d.error || 'Scan gagal';
      scanError.hidden = false;
      portList.innerHTML = '<li class="rec-placeholder">Run a scan to see results</li>';
      scanCount.textContent = '—';
      return;
    }

    scanCount.textContent = `${d.count} found`;
    portList.innerHTML = '';
    if (d.open_ports.length === 0) {
      portList.innerHTML = '<li class="rec-placeholder">No open ports in range</li>';
    } else {
      d.open_ports.forEach(p => {
        const li = document.createElement('li');
        li.innerHTML = `<span class="port-num">${p.port}</span><span class="port-service">${p.service}</span>`;
        portList.appendChild(li);
      });
    }
  } catch (err) {
    scanError.textContent = 'Tidak bisa terhubung ke server';
    scanError.hidden = false;
  } finally {
    scanBtn.disabled = false;
    scanBtn.textContent = 'Scan';
  }
});

/* ---------------------------------------------------------
   File integrity checker
   --------------------------------------------------------- */
const dropzone = document.getElementById('dropzone');
const dropzoneText = document.getElementById('dropzoneText');
const fileInput = document.getElementById('fileInput');
const compareHash = document.getElementById('compareHash');
const hashBtn = document.getElementById('hashBtn');
const hashError = document.getElementById('hashError');
const hashStat = document.getElementById('hashStat');
const hashValue = document.getElementById('hashValue');
const fileMeta = document.getElementById('fileMeta');
const fileNameValue = document.getElementById('fileNameValue');
const fileSizeValue = document.getElementById('fileSizeValue');
const matchLabel = document.getElementById('matchLabel');

let selectedFile = null;

fileInput.addEventListener('change', () => {
  selectedFile = fileInput.files[0] || null;
  dropzoneText.textContent = selectedFile ? selectedFile.name : 'Choose a file or drop it here';
});

['dragover', 'dragleave', 'drop'].forEach(evt => {
  dropzone.addEventListener(evt, e => {
    e.preventDefault();
    dropzone.classList.toggle('drag', evt === 'dragover');
  });
});
dropzone.addEventListener('drop', e => {
  const f = e.dataTransfer.files[0];
  if (f) {
    selectedFile = f;
    fileInput.files = e.dataTransfer.files;
    dropzoneText.textContent = f.name;
  }
});

function formatBytes(bytes){
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

hashBtn.addEventListener('click', async () => {
  hashError.hidden = true;

  if (!selectedFile) {
    hashError.textContent = 'Pilih file terlebih dahulu';
    hashError.hidden = false;
    return;
  }

  hashBtn.disabled = true;
  hashBtn.textContent = 'Computing…';
  matchLabel.textContent = '—';
  matchLabel.className = 'strength-value';

  try {
    const form = new FormData();
    form.append('file', selectedFile);
    if (compareHash.value.trim()) form.append('compare_to', compareHash.value.trim());

    const res = await fetch('/api/integrity', { method: 'POST', body: form });
    const d = await res.json();

    if (!res.ok) {
      hashError.textContent = d.error || 'Gagal menghitung hash';
      hashError.hidden = false;
      return;
    }

    hashStat.hidden = false;
    hashValue.textContent = d.sha256;
    fileMeta.hidden = false;
    fileNameValue.textContent = d.filename;
    fileSizeValue.textContent = formatBytes(d.size);

    if (d.match === null) {
      matchLabel.textContent = 'Computed';
    } else if (d.match) {
      matchLabel.textContent = 'Match';
      matchLabel.className = 'strength-value match-yes';
    } else {
      matchLabel.textContent = 'Mismatch';
      matchLabel.className = 'strength-value match-no';
    }
  } catch (err) {
    hashError.textContent = 'Tidak bisa terhubung ke server';
    hashError.hidden = false;
  } finally {
    hashBtn.disabled = false;
    hashBtn.textContent = 'Compute Hash';
  }
});
